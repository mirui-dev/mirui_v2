<div>
    <?php echo e(" In work, do what you enjoy. "); ?>

</div>
<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/index.blade.php ENDPATH**/ ?>