<div id="dashboard-content" class="fill-width <?php echo e($contentVisibilityClass); ?> ">
    <?php if($view): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.content.'.$view)->html();
} elseif ($_instance->childHasBeenRendered('dashboard.content.'.$view)) {
    $componentId = $_instance->getRenderedChildComponentId('dashboard.content.'.$view);
    $componentTag = $_instance->getRenderedChildComponentTagName('dashboard.content.'.$view);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dashboard.content.'.$view);
} else {
    $response = \Livewire\Livewire::mount('dashboard.content.'.$view);
    $html = $response->html();
    $_instance->logRenderedChild('dashboard.content.'.$view, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/dashboard/content.blade.php ENDPATH**/ ?>