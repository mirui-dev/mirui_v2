<div>
    <?php echo e('You have '.$totalMovie.' movie(s) in cart '); ?>

    <?php echo e($userCoin); ?>

    <?php echo e($totalCoin); ?>

    <div>
        <?php if($userCoin>=$totalCoin): ?>
        <?php echo e($checkOutMsg); ?>

        <button wire:click="checkout()">PAY WITH <?php echo e($totalCoin); ?> COINS</button>
        <?php else: ?>
        <?php echo e($checkOutMsg); ?>

        <button class="<?php echo e($payButton); ?>">ADD COIN FIRST</button>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/dashboard/subcontent/cart-checkout.blade.php ENDPATH**/ ?>