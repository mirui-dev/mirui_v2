<div id="dashboard-content-sub" class=" <?php echo e($subcontentVisibilityClass); ?> ">
    <?php if($view): ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.subcontent.'.$view, $viewData ?? [])->html();
} elseif ($_instance->childHasBeenRendered('l3936848503-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3936848503-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3936848503-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3936848503-0');
} else {
    $response = \Livewire\Livewire::mount('dashboard.subcontent.'.$view, $viewData ?? []);
    $html = $response->html();
    $_instance->logRenderedChild('l3936848503-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
</div>

<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/dashboard/subcontent.blade.php ENDPATH**/ ?>