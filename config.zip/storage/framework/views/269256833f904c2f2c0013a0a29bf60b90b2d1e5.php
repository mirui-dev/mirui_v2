<section class="flex max-width max-height">
    
    <!-- internals -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('internals.cart')->html();
} elseif ($_instance->childHasBeenRendered('l3192114665-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3192114665-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3192114665-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3192114665-0');
} else {
    $response = \Livewire\Livewire::mount('internals.cart');
    $html = $response->html();
    $_instance->logRenderedChild('l3192114665-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;

    <!-- contents-->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.nav')->html();
} elseif ($_instance->childHasBeenRendered('l3192114665-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3192114665-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3192114665-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3192114665-1');
} else {
    $response = \Livewire\Livewire::mount('dashboard.nav');
    $html = $response->html();
    $_instance->logRenderedChild('l3192114665-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.content')->html();
} elseif ($_instance->childHasBeenRendered('l3192114665-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l3192114665-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3192114665-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3192114665-2');
} else {
    $response = \Livewire\Livewire::mount('dashboard.content');
    $html = $response->html();
    $_instance->logRenderedChild('l3192114665-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.subcontentnav')->html();
} elseif ($_instance->childHasBeenRendered('l3192114665-3')) {
    $componentId = $_instance->getRenderedChildComponentId('l3192114665-3');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3192114665-3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3192114665-3');
} else {
    $response = \Livewire\Livewire::mount('dashboard.subcontentnav');
    $html = $response->html();
    $_instance->logRenderedChild('l3192114665-3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('dashboard.subcontent')->html();
} elseif ($_instance->childHasBeenRendered('l3192114665-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l3192114665-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3192114665-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3192114665-4');
} else {
    $response = \Livewire\Livewire::mount('dashboard.subcontent');
    $html = $response->html();
    $_instance->logRenderedChild('l3192114665-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</section>
<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>