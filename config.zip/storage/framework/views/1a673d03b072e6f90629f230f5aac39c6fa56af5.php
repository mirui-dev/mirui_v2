<div>
    <h1>This is cart page !!!!!!</h1>
</div><?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/cart.blade.php ENDPATH**/ ?>