<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="<?php echo e(mix('css/font.css')); ?>">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/mirui.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(mix('css/mirui-dashboard.css')); ?>">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <!-- <script src="<?php echo e(mix('js/mirui.js')); ?>" defer></script> -->

        <!-- <script src="./../src/js/base.js"></script>
        <script src="./../src/js/nav.js"></script>
        <script src="./../src/js/components/noti.js"></script>
        <script src="./../src/js/components/asset.js"></script>
        <script src="./../src/js/components/article.js"></script>
        <script src="./../src/js/components/cart.js"></script>
        <script src="./../src/js/components/library.js"></script>
        <script src="./../src/js/components/transaction.js"></script>
        <script src="./../src/js/components/user.js"></script>
        <script src="./../src/js/page-dashboard.js"></script>
        <script src="./../src/js/page-dashboard-article.js"></script>
        <script src="./../src/js/page-dashboard-cart.js"></script>
        <script src="./../src/js/page-dashboard-library.js"></script>
        <script src="./../src/js/page-dashboard-risk.js"></script>
        <script src="./../src/js/page-dashboard-transaction.js"></script>
        <script src="./../src/js/page-dashboard-user.js"></script> -->

        <script>
            var root = './../';
        </script>

    </head>

    <body onload="userServer(true);cartServer();libraryServer();//greetInject();">
        <div id="global-noti-parent" class="flex fill-width">
        </div>
        
        <?php echo e($slot); ?>


        <footer class="font-pri flex fill-width">
            <div>
                COPYRIGHT © 2020-2022, MIRUI MEDIA CORPORATION. (ASIA)
            </div>
        </footer>

        <?php echo \Livewire\Livewire::scripts(); ?>


    </body>

</html><?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/layouts/app.blade.php ENDPATH**/ ?>