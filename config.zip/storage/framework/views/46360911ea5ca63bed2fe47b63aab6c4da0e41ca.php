<div id="browse-gallery" class="flex content-height">
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="browse-gallery-node-<?php echo e($movie->id); ?>" class="browse-gallery-node flex" wire:click="handler(<?php echo e($movie->id); ?>)" >
        <span class="browse-gallery-node-score content-width"><?php echo e($movie->score); ?></span>
        <div class="browse-gallery-node-details flex max-height fill-width">
            <h1 class="browse-gallery-node-details-title"><?php echo e($movie->title); ?></h1>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\USER\Desktop\mirui_v2\resources\views/livewire/dashboard/content/browse/node.blade.php ENDPATH**/ ?>