<section class="flex max-width max-height">
    @livewire('dashboard.nav')
    @livewire('dashboard.content')
    @livewire('dashboard.subcontentnav')
    @livewire('dashboard.subcontent')
</section>
