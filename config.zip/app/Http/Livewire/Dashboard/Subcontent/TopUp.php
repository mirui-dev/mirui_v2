<?php

namespace App\Http\Livewire\Dashboard\Subcontent;

use Livewire\Component;

class TopUp extends Component
{
    public function render()
    {
        return view('livewire.dashboard.subcontent.top-up');
    }
}
