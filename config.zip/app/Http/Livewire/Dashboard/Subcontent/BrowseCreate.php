<?php

namespace App\Http\Livewire\Dashboard\Subcontent;

use Livewire\Component;

class BrowseCreate extends Component
{
    public function render()
    {
        return view('livewire.dashboard.subcontent.browse-create');
    }
}
