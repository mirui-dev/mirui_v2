<?php

namespace App\Http\Livewire\Dashboard\Content;

use Livewire\Component;

class Cart extends Component
{
    public function render()
    {
        return view('livewire.dashboard.content.cart');
    }
}
